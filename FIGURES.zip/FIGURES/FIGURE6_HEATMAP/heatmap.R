
#-------- Heatmaps using Odds Ratios log transformed (LN)
#color coded so that significance ranges from dark blue to dark red (see below)
#dark blue (negative values, equivalent to odds ratios<1 close to zero)
# dark red (positive values, equivalent to odds ratios>1, very high


#set your own working directory where the heatmap csv is stored
setwd ("C:\\Users\\jvliz\\OneDrive - Stanford\\HANDLS")

#install/load libraries needed
require(graphics)
require(grDevices)
if(!require('gplots')) {
  install.packages('gplots')
  library('gplots')
}

require(tidyverse)


#import CSV with raw data
df <- read.csv("HEATMAP_DATA.csv")

#####clean data#####
#delete constants
df = filter(df, label != 'Constant') #dropped 20

#need to exp to convert estimate to OR
df$OR = exp(df$estimate)

#need to LN OR, SE and p value
df$LN_OR = log(df$OR)
df$LN_SE = log(df$stderr)
df$LN_p = log(df$p + 1) #need to add constant to avoid -Inf

#create column for predicted classes
#extract information from command column
df$Predclass = word(df$command,2)

####Prepare data for OR####
#create matrix with predclass and OR
tempdf=select(df, c(Predclass,parm,LN_OR))

#pivot df to convert data into matrix
pivotdf = pivot_wider(tempdf, names_from = parm, values_from = LN_OR)
pivotdf <- pivotdf %>% 
  column_to_rownames(var = "Predclass")
m=data.matrix(pivotdf)

####Heat Map for OR####
#create heatmap with matrix
heatmap.2(m, dendrogram="both", col=bluered, margins = c(15, 10))

##save as PDF here###


####Prepare data for p value####
#create matrix with predclass and p value
tempdf=select(df, c(Predclass,parm,p))
#pivot df to convert data into matrix
pivotdf = pivot_wider(tempdf, names_from = parm, values_from = p)
pivotdf <- pivotdf %>% 
  column_to_rownames(var = "Predclass")
m=data.matrix(pivotdf)

####Heat Map for p value####
#create heatmap with matrix
heatmap.2(m, dendrogram="both", col=bluered, margins = c(15, 10))

##save as PDF here###

####Prepare data for LN p value####
#create matrix with predclass and p value
tempdf=select(df, c(Predclass,parm,LN_p))

#pivot df to convert data into matrix
pivotdf = pivot_wider(tempdf, names_from = parm, values_from = LN_p)
pivotdf <- pivotdf %>% 
  column_to_rownames(var = "Predclass")
m=data.matrix(pivotdf)

####Heat Map for LN p value####
#create heatmap with matrix
heatmap.2(m, dendrogram="both", col=bluered, margins = c(15, 10))

##save as PDF here###